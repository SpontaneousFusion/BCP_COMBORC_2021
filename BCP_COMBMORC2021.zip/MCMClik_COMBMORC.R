posterior_log = function(lambda, DataF, RadConst,det.eff)
{
  return(prior_log(lambda) + likelihood(lambda, DataF, RadConst,det.eff))
}
# lambda



# read_angular_efficiency(100)





likelihood = function(lambda, DataF, RadConst,det.eff)
{
  if(min(lambda[3:4]) <0 ) #lambda cant be negative
    return(-Inf)
  if(sqrt(lambda[1]^2+lambda[2]^2)>2000)
    return(-Inf)
  
  
  # if(lambda[4]|lambda[5]<0)
  #   return(-Inf)
  x       = lambda[1]
  y       = lambda[2]
  activity = lambda[3]
  mu      = lambda[4]


  # atan2_angles=calculate_atan2(DataF[,1],DataF[,2])
  
  # dist = sqrt( (x - DataF[,1])^2+(y - DataF[,2])^2 ) + 10^-12


  mean_func  = mean_func_basic(DataF[,1],DataF[,2],  x,  y, activity, mu, RadConst,det.eff)
  
  
  lik = sum( dpois(DataF[,3], lambda = mean_func, log = T))
  # lik
  return(lik)
}
#'
#' Computes the mean function at positions (x,y) given the
#' a radiation at (pos_x,pos_y) with activative act
#' @param RadConst -  radiaton constanst
#'                    $mu_air     -
#'                    $ngamma     -
#'                    $efficiency -
#'
#'
#'
#'
#'
#'
#'

mean_func_basic = function(x,  y, pos_x, pos_y, act, mu, RadConst,det.eff)
{
  
  dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 ) + 10^-12
  # source_effect = ( act*RadConst$act_scale * RadConst$ngamma * unlist(RadConst$efficiency[2])*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  # source_effect = ( act*RadConst$act_scale * RadConst$ngamma * RadConst$Eff*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  source_effect = ( act*RadConst$act_scale * RadConst$ngamma * det.eff*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  
  
  
   mu_joint   =source_effect+ mu
  return(mu_joint)
}


mean_func_naif = function(x,  y, pos_x, pos_y, act, mu, RadConst,pred_angles,EffAng)
{
  
  dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 ) + 10^-12
  calculated.efficiencies=(approx((EffAng[[1]][,1]),(EffAng[[1]][,2]),pred_angles)[2])[[1]]
  # source_effect = ( act*RadConst$act_scale * RadConst$ngamma * unlist(RadConst$efficiency[2])*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  source_effect = ( act*RadConst$act_scale * RadConst$ngamma * calculated.efficiencies*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  mu_joint   =source_effect+ mu
  return(mu_joint)
}



# mean_func_hpge(1,1,10,10,1,1,RadConst = RadConst)




mean_func_nair = function(x,  y, pos_x, pos_y,act, mu, RadConst,pred_angles,EffAng)
{
  dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 ) + 10^-12
  calculated.efficiencies=(approx((EffAng[[2]][,1]),(EffAng[[2]][,2]),pred_angles)[2])[[1]]
  source_effect = ( act*RadConst$act_scale * RadConst$ngamma * calculated.efficiencies*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  # source_effect = ( act*RadConst$act_scale * RadConst$ngamma * unlist(RadConst$efficiency[3])*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  mu_joint   =source_effect+ mu
  return(mu_joint)
}

mean_func_hpge = function(x,  y, pos_x, pos_y, act, mu, RadConst,pred_angles,EffAng)
{
  dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 ) + 10^-12
  calculated.efficiencies=(approx((EffAng[[3]][,1]),(EffAng[[3]][,2]),pred_angles)[2])[[1]]
  source_effect = ( act*RadConst$act_scale * RadConst$ngamma * calculated.efficiencies*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  # source_effect = ( act*RadConst$act_scale * RadConst$ngamma * unlist(RadConst$efficiency[5])*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  mu_joint   =source_effect+ mu
  return(mu_joint)
}

mean_func = function(x,  y, pos_x, pos_y, act, mu, RadConst)
{
  dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 ) + 10^-12
  source_effect = ( act*RadConst$act_scale * RadConst$ngamma * unlist(RadConst$efficiency[3])*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  mu_joint   =source_effect+ mu
  return(mu_joint)
}

# x=c(1,2,3,4,5,6,7,8,9,10)
# y=seq(-30,30,1)
# x=rep(0,length(y))
# x=seq(-30,30,1)
# y=rep(0,length(x))
# 
# 
# 
# pos_x=0
# pos_y=-1



# plot(calculate_angles(x,y,pos_x,pos_y),ylim=c(0,360))
# abline(h=seq(0,360,90))
calculate_angles=function(x,y,pos_x,pos_y,atan2.vals)
{
  pred.angles=atan2.vals-atan2(  pos_y-y,  pos_x-x)
  # pred.angles=atan2(  y-c(y[-1],y[length(y)]),  x-c(x[-1],x[length(x)]))-atan2(  pos_y-y,  pos_x-x)
  pred.angles[which(pred.angles<0)]=pred.angles[which(pred.angles<0)]+(2*pi)
  
  
  return(pred.angles/pi*180   )
}

calculate_atan2=function(x,y)
{
  return(atan2(  y-c(y[-1],y[length(y)]),  x-c(x[-1],x[length(x)])) )
}

# x=DataF[,1]
# y=DataF[,2]
# length(atan2(  y-c(y[-1],y[length(y)]),  x-c(x[-1],x[length(x)])))
# length(atan2(DataF[,2],DataF[,1]))


calculate_offset_x=function(x,y,atan2_values,angle.distance.data,detector.id=1)
{
  
  
  altered.angles=atan2_values+angle.distance.data[detector.id,2]
  x.corr=cos(altered.angles)*angle.distance.data[detector.id,3]
  return(  x-x.corr  )
}

calculate_offset_y=function(x,y,atan2_values,angle.distance.data,detector.id=1)
{
  
  altered.angles=atan2_values+angle.distance.data[detector.id,2]
  y.corr=sin(altered.angles)*angle.distance.data[detector.id,3]
  
  return(  y-y.corr  )
}








mean_func_angular = function(x,  y, pos_x, pos_y, act, mu, RadConst)
{
  
  dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 )+10^-12
  
  # x_exp=c(x,tail(x,1))
  # y_exp=c(y,tail(y,1))
  # 
  # meas_vector_x=tail(x_exp,-1)-head(x_exp,-1)
  # meas_vector_y=tail(y_exp,-1)-head(y_exp,-1)
  # 
  # source_vector_x=pos_x-head(x_exp,-1)
  # source_vector_y=pos_y-head(y_exp,-1)
  
  # x_exp=c(x,tail(x,1))
  # y_exp=c(y,tail(y,1))
  
  meas_vector_x=tail(c(x,tail(x,1)),-1)-head(c(x,tail(x,1)),-1)
  meas_vector_y=tail(c(y,tail(y,1)),-1)-head(c(y,tail(y,1)),-1)
  
  source_vector_x=pos_x-head(c(x,tail(x,1)),-1)
  source_vector_y=pos_y-head(c(y,tail(y,1)),-1)
  
  
  pred.angles=atan2(meas_vector_y,meas_vector_x)-atan2(source_vector_y,source_vector_x)
  
  
  pred.angles[which(pred.angles>pi)]=pred.angles[which(pred.angles>pi)]-(2*pi)
  pred.angles[which(pred.angles<(-pi))]=pred.angles[which(pred.angles<(-pi))]+(2*pi)
  pred.angles[which(pred.angles<0)]=pred.angles[which(pred.angles<0)]+2*pi
  
  
  
  pred.angles=pred.angles*(180/pi)
  
  # source_effect = (act*ngamma*fAngEffInterpLin(pred.angles)*exp(-mu_air* dist )) / (4 * pi * dist^2) # with angular
  # source_effect = (act*ngamma*efficiency*exp(- mu_air* dist )) / (4 * pi * dist^2) # without angular
  
  # mu_joint   =source_effect+ mu
  
  # return(mu_joint)
  
  # dist = sqrt( (pos_x - x)^2+(pos_y - y)^2 ) + 10^-12
  source_effect = ( act*RadConst$act_scale * RadConst$ngamma * fAngEffInterpLin(pred.angles)*exp(- RadConst$mu_air* dist )) / (4 * pi * dist^2) # with angular
  mu_joint   =source_effect+ mu
  return(mu_joint)
}



prior_log <- function(lambda)
{
  
  # lambda 1 -- source x
  # lambda 2 -- source y
  # lambda 3 -- activity
  # lambda 4 -- background lambda
  # lambda 5 -- background sigma
  
  x       = lambda[1]
  y       = lambda[2]
  activty = lambda[3]
  mu_bac  = lambda[4]
  # mu_bac_hpge  = lambda[5]
  if(min(lambda[3:4]) <0)
    return(-Inf)
  logpi = 0
  logpi = logpi + dgamma(activty/1e6 , shape=1.2, rate=0.0001, log = T)
  logpi = logpi + dnorm(mu_bac  , mean = 10      , sd=10  , log = T)
  # logpi = logpi + dnorm(mu_bac_hpge  , mean = 3      , sd=3  , log = T)
  
  return(logpi)
}

# 
# # det.coords.offset=data.frame(c(-1.331,0.01,-1.025),c(-0.086,-0.651,-0.651))
# # det.coords.offset
# det.coords.offset=matrix(nrow=3,ncol=2,c(-1.331,0.01,-1.025,-0.086,-0.651,-0.651))
# # det.coords.offset
# 
# det.coords.offset[,1]=det.coords.offset[,1]-2
# det.coords.offset[,2]=det.coords.offset[,2]+0.4
# det.coords.offset
# # angles.distances=data.frame(c(),c())
# angles.distances=matrix(nrow = 3,ncol = 2)
# for(i in 1:3)
# {
#   det.select=i
#   angles.distances[i,1]=atan2(det.coords.offset[det.select,2],det.coords.offset[det.select,1])
#   angles.distances[i,2]=sqrt(det.coords.offset[det.select,1]^2+det.coords.offset[det.select,2]^2)
# }
# angles.distances
# # 
# write.csv(angles.distances,"angles.distances.csv")
# # 
# 


cat("\nPreparing ROI function...")


fPreapareRois=function(data.to.convert,nuclide.select=1, co_both=F,co_upper=F,background_correction=T)
{
  # work.spectra=apply(data.to.convert[,c(-1,-2)],2,unlist)
  work.spectra=data.to.convert
  
  
  hpge.converter=1000/1460
  # nai.converter=128/1460
  
  
  # plot(apply(data.to.convert,2,mean)[100:150])
  max(apply(data.to.convert,2,mean)[100:150])
  pot.en=which(apply(data.to.convert,2,mean)[100:150]==max(apply(data.to.convert,2,mean)[100:150]))+99
  
  
  
  
  # plot(1:256,apply(data.nai1,2,mean),xlim=c(100,150))
  # abline(v=pot.en)
  
  # nai.converter=126/1460
  
  
  nai.converter=pot.en/1460
  channels.per.kev=1460/pot.en
  
  cs.energy=round(662/channels.per.kev,0)
  cs.energy  
  co.energy.top=round(1170/channels.per.kev,0)
  co.energy.top
  co.energy.bottom=round(1332/channels.per.kev,0)
  co.energy.bottom
  
  # my_palette <- colorRampPalette(c("white","black","black","black","black","black","black","black","black"))(n = 299)
  
  
  # heatmap(data.to.convert, col = my_palette,Rowv=NA,Colv=NA,add.expr = abline( v=c(126,cs.energy,co.energy.bottom,co.energy.top),col=2,lty=2),scale="none",main="Data NaI1 QA",xlab="Channel number",ylab="Measurement number")
  
  
  
  # hpge.converter
  
  # roi.nai=round(data.frame(c(600,1274),c(750,1470))*nai.converter)
  # roi.hpge=round(data.frame(c(658,1327),c(665,1337))*hpge.converter)
  
  
  
  # roi.nai=round(data.frame(c(600,1247),c(750,1470))*nai.converter)
  
  # roi.nai=round(data.frame(c(600,1253),c(750,1412))*nai.converter)
  
  
  
  roi.nai=round(data.frame(c(581,1253),c(743,1412))*nai.converter)
  
  
  # roi.nai
  
  
  roi.hpge=round(data.frame(c(658,1327),c(665,1337))*hpge.converter)
  
  
  
  roi.nai
  # roi.nai
  # roi.hpge
  # roi.nai.low=round(data.frame(c(432,1060),c(580,1254))*nai.converter)
  # roi.hpge.low=round(data.frame(c(642,1310),c(648,1320))*hpge.converter)
  # 
  # roi.nai.high=round(data.frame(c(770,1490),c(918,1684))*nai.converter)
  # roi.hpge.high=round(data.frame(c(675,1345),c(681,1355))*hpge.converter)
  
  
  roi.nai.low=round(data.frame(c(432,1247),c(580,1470))*nai.converter)
  roi.hpge.low=round(data.frame(c(641,1310),c(648,1320))*hpge.converter)
  
  roi.nai.high=round(data.frame(c(770,1490),c(918,1684))*nai.converter)
  roi.hpge.high=round(data.frame(c(675,1345),c(682,1355))*hpge.converter)
  
  # lol=0
  
  # output.data.hpge=rowSums(  Spectra.HPGE[,roi.hpge[nuclide.select,1]:roi.hpge[nuclide.select,2]]  )
  
  # output.data.nai1=rowSums(  Spectra.NaI1[,roi.nai[nuclide.select,1]:roi.nai[nuclide.select,2]]  )
  # 
  # output.data.nai2=rowSums(  Spectra.NaI2[,roi.nai[nuclide.select,1]:roi.nai[nuclide.select,2]]  )
  
  
  if(length(work.spectra[1,])>300)
  {
    ### HPGe File
    # lol=1  
    
    if(background_correction==T)
    {
      backg.low=rowSums(  work.spectra[,roi.hpge.low[nuclide.select,1]:roi.hpge.low[nuclide.select,2]]  )
      backg.high=rowSums(  work.spectra[,roi.hpge.high[nuclide.select,1]:roi.hpge.high[nuclide.select,2]]  )
      backg.calc=(backg.low+backg.high)/2
      output.data=rowSums(  work.spectra[,roi.hpge[nuclide.select,1]:roi.hpge[nuclide.select,2]]  )-backg.calc
      output.data=round(output.data-(min(output.data)[1]))
      
    }else{
      output.data=rowSums(  work.spectra[,roi.hpge[nuclide.select,1]:roi.hpge[nuclide.select,2]]  )
    }
    nuclide.select=1
    roi.nai[nuclide.select,1]:roi.nai[nuclide.select,2]
    
    
    
    
    
    
  }else{
    ### NaI File
    # lol=2
    
    
    if(background_correction==T)
    {
      backg.low=rowSums(  work.spectra[,roi.nai.low[nuclide.select,1]:roi.nai.low[nuclide.select,2]]  )
      backg.high=rowSums(  work.spectra[,roi.nai.high[nuclide.select,1]:roi.nai.high[nuclide.select,2]]  )
      backg.calc=(backg.low+backg.high)/2
      output.data=rowSums(  work.spectra[,roi.nai[nuclide.select,1]:roi.nai[nuclide.select,2]]  )-backg.calc
      # minimum=min(output.data)[1]
      output.data=round(output.data-(min(output.data)[1]))
    }else{
      output.data=rowSums(  work.spectra[,roi.nai[nuclide.select,1]:roi.nai[nuclide.select,2]]  )
    }
    
    
    
    
    
    
    
    
    
  }
  
  
  return(output.data)
}



cat("\nDone...")


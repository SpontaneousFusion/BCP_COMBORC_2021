#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

# rm(list=ls())
# graphics.off()
# options(warn=1)


library(shiny)
library(mvtnorm)
library(rgdal)
library(sp)
library(raster)
library(RColorBrewer)

setwd("~/")

source('coordinate_conversion.R')
source('imp_NBL.R')
source('MCMClik_COMBMORC.R')
source('ROI_script.R')

options(shiny.maxRequestSize=30*1024^2)






fCombmorcInput= function(input.data)
{
  to.return=data.frame(input.data[,5],input.data[,4],input.data[,11],input.data[,3])
  # fWgsToMercator()
  # to.return=list()
  return(to.return)
}


fSetRadConst=function(branching.ratio=0.85,gamma.energy=662,efficiency=0.02,activity.scale=1e6)
{
  RadConst <- list()
  
  # RadConst$ngamma=0.85
  RadConst$ngamma=branching.ratio
  
  
  attenuation.data=read.csv(file="gamma_attenuation.txt",header =T)
  fGammaInterp=approxfun(x=attenuation.data[,1],y=attenuation.data[,2],method="linear",ties=mean)
  par(mfrow=c(1,1))
  plot(attenuation.data[,1],attenuation.data[,2],log="xy",type="p",main="Gamma attenuation interpolation data",xlab="Energy (MeV)",ylab="Attenuation coefficient (cm^2/g)")
  curve(fGammaInterp(x),from=0.001,to=100,add=T)
  legend("topright",legend=c("Values","Interpolation"),lty=c(0,1),pch=c(1,-1))
  # fGammaInterp(gamma_energy/1000)
  
  # radiation_energy
  # RadConst$mu_air = fGammaInterp(662/1000)*0.1225	
  RadConst$mu_air = fGammaInterp(gamma.energy/1000)*0.1225	
  
  # RadConst$Eff=0.02
  RadConst$Eff=efficiency
  
  # RadConst$act_scale=1e6
  RadConst$act_scale=activity.scale
  return(RadConst)
}

RadConst=fSetRadConst()


fGenerateData=function(s.x=0,s.y=50,activity=100,background=10,data.span=2000,rconst=RadConst)
{
  x.coords=seq(-data.span,data.span,1)
  y.coords=rep(0,length(x.coords))
  
  # sim.data=round( mean_func_basic(x.coords,y.coords,0,30,100,10,RadConst =RadConst)  )
  
  sim.data=round( mean_func_basic(x.coords,y.coords,s.x,s.y,activity,background,RadConst =rconst)  )
  
  DataF=data.frame(x.coords,y.coords,sim.data)
  
  pois.data=c()
  for(i in 1:length(sim.data))
  {
    pois.data[i]=rpois(1,sim.data[i])
  }
  
  
  # pois.data
  # rpois()
  DataF=data.frame(x.coords,y.coords,pois.data)
  # plot(pois.data)
  # apply(sim.data,2,rpois)
  # DataF
  
  return(DataF)
}


fGenerateDataNew=function(s.x=0,s.y=50,activity=100,background=10,start.x=-100,speed=10.4,acq.t=1,data.span=100,rconst=RadConst,d.efficiency=0.02)
{
  
  x.coords=seq(start.x,by=speed*acq.t,length.out=data.span)
  # x.coords=seq(-data.span,data.span,1)
  y.coords=rep(0,length(x.coords))
  
  # sim.data=round( mean_func_basic(x.coords,y.coords,0,30,100,10,RadConst =RadConst)  )
  
  sim.data=round( mean_func_basic(x.coords,y.coords,s.x,s.y,activity,background,RadConst =rconst,det.eff=d.efficiency)  )*acq.t
  
  DataF=data.frame(x.coords,y.coords,sim.data)
  
  pois.data=c()
  for(i in 1:length(sim.data))
  {
    pois.data[i]=rpois(1,sim.data[i])
  }
  
  
  # pois.data
  # rpois()
  DataF=data.frame(x.coords,y.coords,pois.data)
  # plot(pois.data)
  # apply(sim.data,2,rpois)
  # DataF
  
  return(DataF)
}

# fGenerateData(0,90,100)  

# mean_func_basic()




fPerformMCMC=function(DataF,RadConst,InitPosList,detector.efficiency,simnum)
{
  
  
  # sim      =1 * 30000
  sim      =simnum
  # burnin   = 10000
  ### sigma MH #########
  sigma_MH = 0.01
  beta_sigma = 10^-4
  
  
  
  sigma_mh_vec=c()
  Sigma = diag(4)*1000^2
  
  mean_est   = matrix(0, nrow=1, ncol = 4)
  Sigma_est  = matrix(0, nrow=4, ncol= 4)
  lambda_vec = matrix(0, nrow= sim, ncol = 4)
  lambda_star_vec=matrix(0, nrow= sim, ncol = 4)
  sigma_mh_vec=matrix(0,nrow=sim,ncol=4)
  accept <- 0
  
  
  
  ## main loop
  #starting value
  I = which(DataF[,3]==max(DataF[,3]))[1]
  
  lambda=c(DataF[I,1],DataF[I,2], 20, mean(DataF[,3]) )
  
  # lambda=c(-10,-10,10,10)
  
  
  
  # InitPosList
  
  lambda=c(InitPosList$x,InitPosList$y,InitPosList$act,InitPosList$mu)
  
  
  count <- 0
  i=1
  i
  time.segment.mcmc.begin=Sys.time()
  time.segment.start=Sys.time()
  lambda
  
  
  par(mfrow=c(3,1),mar=c(2,2,2,1))
  plot(DataF[,3],type="l")
  # plot(DataF[,4],type="l")
  # plot(DataF[,5],type="l")
  
  
  cat("\nStarting MCMC...")
  
  
  
  for(i in 1:sim)
  {
    
    count  = count + 1
    lambda_star = lambda
    
    
    lambda_star[1:4] = rmvnorm(1,mean  = lambda[1:4], sigma = sigma_MH^2 * Sigma, method="chol")
    
    if (i %% 1000 == 0)
    {
      # Calculating distance to the data points from the lambda_star position
      dist.to.prop=sqrt(  (    DataF[,1]-lambda_star[1])^2+(    DataF[,2]-lambda_star[2])^2   )
      # Which data row has the closest one
      closest.to.prop=which(dist.to.prop   ==min(dist.to.prop)) 
      # Calculating distance to the closest data point
      distance.to.x=lambda_star[1]-DataF[closest.to.prop,1]
      distance.to.y=lambda_star[2]-DataF[closest.to.prop,2]
      # Mirroring the proposal to the opposite side of the closest data point
      lambda_star[1]=lambda_star[1]-2*distance.to.x
      lambda_star[2]=lambda_star[2]-2*distance.to.y
    }
    lambda_star_vec[i,]=lambda_star
    
    # lambda_star
    # # likelihood(lambda,DataF, RadConst = RadConst)
    # lambda
    # lambda_star
    
    # likelihood(lambda_star,DataF, RadConst = RadConst)
    # posterior_log(lambda_star,DataF,RadConst)
    # posterior_log(lambda,DataF,RadConst)
    
    # prior_log(lambda)
    
    U = runif(1)
    acc = min(1,  exp( posterior_log(lambda_star,DataF, RadConst = RadConst,det.eff=detector.efficiency) - posterior_log(lambda,DataF, RadConst = RadConst,det.eff=detector.efficiency)))
    
    acc
    
    if(U < acc )
    {
      lambda = lambda_star
      accept = accept + 1 #counting number of acceptance
    }
    lambda_vec[i,] = lambda
    
    #adaptive algoritm
    w = 1/i
    mean_est = (1-w) *  + w*lambda[1:4,drop=F]
    
    Sigma_est = (1-w) * Sigma_est + w *(lambda[1:4,drop=F] - mean_est)%*% t(lambda[1:4,drop=F] - mean_est)
    if(i > 100)
    {
      Sigma = diag(diag(Sigma_est)) + diag(length(mean_est)) * beta_sigma
    }
    
    
    
    if(i%%100 == 0)
    {
      if(accept/count < 0.24 )
        sigma_MH = max(0.95,(1-5/sqrt(i))) * sigma_MH
      
      else
        sigma_MH = min(1.05, 1+5/sqrt(i)) * sigma_MH
      
      accept = 0
      count  = 0
      
      
      
      
    }
    
    
    
    
    
    
    
    if(i %% 1000 == 0) ### was used 1000 for 1 second, should be 10 seconds now
    {
      time.segment.end=Sys.time()
      time.difference=as.numeric(difftime(time.segment.end,time.segment.start,units="secs"))
      
      time.left=(sim-i)/1000
      cat('\n',100*round(i/sim,2) ,'% done. ')
      cat("Segment duration:",time.difference,"seconds. ")
      cat("ETA in:",time.left*time.difference,"seconds or",time.left*time.difference/60,"minutes")
      
      time.segment.start=Sys.time()
      
    }
    
    
    
  }
  
  
  
  
  return(lambda_vec)
  
}



# fPerformMCMC(DataF,RadConst)

# 
# lambda_vec <- lambda_vec[burnin:sim,]
# # lambda_vec_big[  (1+(iui-1)*(sim-burnin)):(iui*(sim-burnin)   ),]=lambda_vec[1:(sim-burnin),]
# 
# lambda_vec
# 
# par(mfrow=c(4,1))
# for(i in 1:4)
# {
#   plot(density(lambda_vec[,i]))  
# }
# 
# 
# 
# count
# cat("\nMCMC finished...")
# 
# Backgmupred=median(lambda_vec[,4])
# 
# time.segment.mcmc.end=Sys.time()
# time.difference.mcmc=as.numeric(difftime(time.segment.mcmc.end,time.segment.mcmc.begin,units="secs"))
# 
# 
# cat("\n MCMC finished in :",time.difference.mcmc,"seconds or",time.difference.mcmc/60,"minutes")
# 
# 
# 
# setwd(project.folder.path)



# di



# distance.to.zero=sqrt(lambda_vec[,1]^2+lambda_vec[,2]^2)
# plot(distance.to.zero)

# distance.source.true=distance.true


# data.th=(median(distance.to.zero)-distance.source.true)/distance.source.true
# if(data.th>10)
#   {
#   cat("\nMedian distance - true distance ratio:",data.th)
#   cat("\nHave not converged!!!")
# }else{
#   cat("\nMedian distance - true distance ratio:",data.th)
#   }


# lambda_vec=lambda_vec_big
# 
# setup_number
# 
# source.name
# seg.i
# sim.text=  c("Exp","Sim")[as.numeric(simulate.data)+1]
# posterior.output.data=paste0(source.name,"_setup",source_number,"_seg",seg.i,"_",sim.text,".csv")


# source("graphing_multiple.R")






















































































































# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Bayesian Calculation Program"),
    


    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
          h4("Input panel"),
          h6("Choose the appropriate tab to upload input files, generate synthetic data or perform Bayesian reconstruction"),
          
          tabsetPanel(
            
            tabPanel("Data input",h5(""),
                     
                     
                     h6("Choose file type by selecting the appropriate tab. For teams using Nugget, there is a possibility to upload 
                        *.NBL files for direct evaluation. For other teams, please use the CSV files using the COMBMORC file format."),        
                     h4("Select the appropriate tab:"),
                     
                     tabsetPanel(
                       tabPanel("CSV",
                                h5(""),
                                # Input: Select a file ----
                                # h5("Upload CSV file formatted according the COMBMORC format"),
                                fileInput("file1", "CSV file:",
                                          multiple = FALSE,
                                          accept = c("text/csv",
                                                     "text/comma-separated-values,text/plain",
                                                     ".csv")),
                                
                                h6("After uploading the file, press the \"Process\" button to load the data."),
                                actionButton("proccsvButton", "Process CSV data", class = "btn-success"),
                                
                                
                       ),
                       tabPanel("NBL", 
                                h5(""),
                                fileInput("nbl1", "Main NBL:",
                                          multiple = FALSE,
                                          accept = c(".nbl")),
                                
                                fileInput("nbl2", "NaI NBL:",
                                          multiple = FALSE,
                                          accept = c(".nbl.NaI")),
                                
                                fileInput("nbl3", "HPGe NBL:",
                                          multiple = FALSE,
                                          accept = c(".nbl.HPGe")),
                                
                                
                                radioButtons("detset", "Use data from:",
                                             c("NaI 1" = "nai1",
                                               "NaI 2" = "nai2",
                                               "HPGe" = "hpge")),
                                
                                
                                actionButton("procnblButton", "Process NBL data", class = "btn-success"),
                                
                                verbatimTextOutput("summary"))
                     ),
                     
                     sliderInput("datarange", "Select data range:",
                                 min = 0, max = 0, value = c(0,0)
                     ),
                     h6("Use the sliders to select the data range, which will be used in Bayesian reconstruction. The setting set using the 
                        sliders is automatically evaluated when performing the reconstruction."),
                     h5(" ")
                     ),
            tabPanel("Data generation",h5(""),
                     
                     h6("Input parameters and press \"Generate\" button to generate data"),
                     
                     textInput("efficiency", "Efficiency of the detector (m^2)", "0.02"),
                     
                     h6("Note: the efficiency is used only to evaluate the count-rate from the source. The background count-rate is given separately. In reality, if
                         the efficiency is increased twice, the background count-rate would also increase twice. To obtain data for the same situation but different efficiency,
                         the background count-rate has to be adjusted manually accordingly.."),
                     
                     # actionButton("effButton", "Update detector efficiency", class = "btn-success"),
                     
                     textInput("sx", "x position of the source (m)", "0"),
                     
                     textInput("sy", "y position of the source (m)", "60"),
                     
                     textInput("sact", "Activity of the source (MBq)", "100"),
                     
                     textInput("back", "Background count-rate (cps)", "10"),
                     
                     textInput("xstart", "Start point along x axis", "-1400"),
                     
                     textInput("speed", "Detector speed (m/s)", "13.9"),
                     
                     textInput("acqt", "Acquisition time (s)", "1"),
                     
                     textInput("dataspan", "Number of data points", "200"),
                     
                     actionButton("generateButton", "Generate data", class = "btn-success")
                     
                     
                     
                     
                     ),
            tabPanel("Reconstruction",h5(""),
                     
                     
                     textInput("recefficiency", "Efficiency of the detector used in reconstruction (m^2)", "0.02"),
                     
                     # h6("Note: the efficiency is used only to evaluate the count-rate from the source. The background count-rate is given separately. In reality, if
                     #     the efficiency is increased twice, the background count-rate would also increase twice. To obtain data for the same situation but different efficiency,
                     #     the background count-rate has to be adjusted manually accordingly.."),
                     
                     
                     
                     radioButtons("radioset", "Use data:",
                                  c("Simulated" = "sim",
                                    "Uploaded" = "upl")),
                     
                     h4("Intial parameters"),
                     
                     radioButtons("radioinit", "Use:",
                                  c("Max data" = "max",
                                    "Specified" = "spec")),
                     
                     textInput("initx", "Initial x coordinate", "0"),
                     
                     textInput("inity", "Initial y coordinate", "0"),
                     
                     textInput("initact", "Initial activity (MBq)", "100"),
                     
                     textInput("initmu", "Initial background CPS", "10"),
                     
                     textInput("simnum", "Number of MCMC iterations", "30000"),
                     
                     textInput("burnin", "Number of first samples to remove", "10000"),
                     
                     
                     actionButton("goButton", "Run MCMC", class = "btn-success"),
                     actionButton("redrawButton", "Redraw MCMC results", class = "btn-success")
                     
                     
                     
                     )
            
            
          ),
          
          
          
          
        
          
          
          
          # radioButtons("filetype", "Select file type:",
          #              c("NBL" = "nbl",
          #                "COMBMORC CSV" = "csv")),
          
          

          

          

          
          
          
          
            # sliderInput("bins",
            #             "Number of bins:",
            #             min = 1,
            #             max = 50,
            #             value = 30)
        ),
        

        
        
        
        # Show a plot of the generated distribution
        mainPanel(
          
          tabsetPanel(id="resultsTab",
            
            tabPanel(title="Input Data",value="input",h5(""),
                     plotOutput("inputdata"),
                     plotOutput("inputdata2"),
                     plotOutput("inputdata3"),
                     plotOutput("inputdata4"),
                     tableOutput("contents")
                     ),
            tabPanel(title="Generated Data",value="gen",h5(""),
                     plotOutput("generateddata")
                     ),
            tabPanel(title="Posterior Distributions",value="post",h5(""),
                     plotOutput("pospost"),
                     plotOutput("actpost"),
                     plotOutput("datafits"),
                     plotOutput("appe"))
                     
                     
            )
          
          
           # plotOutput("distPlot"),

           # verbatimTextOutput("value"),


 
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output,session) {
  


  input.data=reactiveValues()
  generated.data=reactiveValues()
  csv.data=reactiveValues()
  r.const=reactiveValues()
  r.const$val=  fSetRadConst()

  uploaded.data=reactiveValues()

  nbl.data=reactiveVal()
  
  mcmc.results=reactiveValues()
  
  mcmc.prepared.data=reactiveValues()

# observeEvent(file1,{cat("lpl")})


    # output$distPlot <- renderPlot({
    #     # generate bins based on input$bins from ui.R
    #     x    <- faithful[, 2]
    #     bins <- seq(min(x), max(x), length.out = input$bins + 1)
    #
    #     # draw the histogram with the specified number of bins
    #     hist(x, breaks = bins, col = 'darkgray', border = 'white')
    # })


    output$contents <- renderTable({

      # input$file1 will be NULL initially. After the user selects
      # and uploads a file, head of that data file by default,
      # or all rows if selected, will be shown.

      req(input$file1)

      # when reading semicolon separated files,
      # having a comma separator causes `read.csv` to error
      tryCatch(
        {
          df.input <- read.csv(input$file1$datapath)
          
          df=fCombmorcInput(df.input)[,c(1,2,3)]
          
          
          csv.data$data=df

        },
        error = function(e) {
          # return a safeError if a parsing error occurs
          stop(safeError(e))
        }
      )

      # if(input$disp == "head") {
        # return(head(df))
      # }
      # else {
        return(head(df) )
      # }

      # uploaded.data$data=df




    })

    # input$caption
    # o.val={as.numeric(input$caption)*10}


    output$value <- renderText({


      as.numeric(input$caption)*10

      })


    lol=" "
    res=rpois(10,10)





    observeEvent(input$goButton,{



      if(input$radioset=="sim")
      {
        mcmc.data=generated.data$data

      }else{
        # mcmc.data=generated.data$data
        # mcmc.data[,3]=0
        # req(input$file1)
        if(length(as.vector(uploaded.data$data))>1)
        {
          mcmc.data <- uploaded.data$data[input$datarange[1]:input$datarange[2],]
        
        }
        else
        {
          return()
        }



        # if(file1)

      }

      # RadConst=r.const$val

      
      InitPosList=list()
      
      if(input$radioinit=="spec")
      {
        InitPosList$x=as.numeric(input$initx)
        InitPosList$y=as.numeric(input$inity)
        InitPosList$act=as.numeric(input$initact)
        InitPosList$mu=as.numeric(input$initmu)
        
      }else{
        
        n.max=which(mcmc.data[,3]==max(mcmc.data[,3]))[1]
        
        
        
        
        InitPosList$x=mcmc.data[n.max,1]
        InitPosList$y=mcmc.data[n.max,1]
        InitPosList$act=100
        InitPosList$mu=mean(mcmc.data[,3])
        
        
        
      }
      
      
      # InitPosList$x=as.numeric(input$initx)
      # InitPosList$y=as.numeric(input$inity)
      # InitPosList$act=as.numeric(input$initact)
      # InitPosList$mu=as.numeric(input$initmu)
      
      mcmc.data[,3]=round(as.numeric(mcmc.data[,3]))
      res=fPerformMCMC(mcmc.data,r.const$val,InitPosList,detector.efficiency=as.numeric(input$recefficiency),simnum=as.numeric(input$simnum))
      mcmc.prepared.data$data=mcmc.data
      
      mcmc.results$data=res
      res.burnin=mcmc.results$data[as.numeric(input$burnin):as.numeric(input$simnum),]
      # res_burnin=res[-c(1:as.numeric(input$burnin)),]
      output$pospost <- renderPlot({
        
        
        
        
        
        
        minx=min(res.burnin[,1])
        maxx=max(res.burnin[,1])
        miny=min(res.burnin[,2])
        maxy=max(res.burnin[,2])
        cell_size=5
        
        r <- raster(xmn=minx, ymn=miny, xmx=maxx, ymx=maxy, res=cell_size)
        
        
        # lambda_vec_new=data.frame(lambda_vec[1:(sim-burnin),1],lambda_vec[1:(sim-burnin),2])
        lambda_vec_new=data.frame(res.burnin[,1],res.burnin[,2])
        
        sp.new=SpatialPoints(lambda_vec_new)
        
        tab <- table(cellFromXY(r, sp.new))
        r[as.numeric(names(tab))] <- tab
        
        y=r
        
        
        Stat.Sum=cellStats(r,sum) # Counting the number of all points in the r raster layer
        y.scale = y / Stat.Sum*100 
        
        # Classic palette BuPu, with 4 colors
        coul = brewer.pal(9, "YlGnBu")
        # I can add more tones to this palette :
        coul = colorRampPalette(coul)(40)
        
        coordinates.posterior.max=xyFromCell(y.scale,cell=which.max(y.scale))
        
        plot(y.scale,main="Posterior distribution for source position",xlab="x coordinate (m)",ylab="y coordinate (m)",col=coul)
        
        points(mcmc.prepared.data$data[,1],mcmc.prepared.data$data[,2],type="l",lwd=3) 
        
        

        # plot(   res.burnin[,1],res.burnin[,2],col=rgb(1,0,0,0.1)   )

        # points(   res[,1],res[,2],col=rgb(1,0,0,1)   )
      })


    output$actpost <- renderPlot({
      plot( density(  res.burnin[,3] )   ,main="Posterior distribution of source activity",xlab="Activity (MBq)")
      abline(v=input$sact,lwd=3,lty=3,col=2)
    })

    
    output$datafits <- renderPlot({
      
  
        
           plot(mcmc.prepared.data$data[,3],main="Fit of the peak in measurement time-series",xlab="Measurement index",ylab="CPS")

        
        for(i in seq(1,length(res.burnin[,1]),by=1000))
        {
          green.line=mean_func_basic(mcmc.prepared.data$data[,1],mcmc.prepared.data$data[,2],res.burnin[i,1],res.burnin[i,2],res.burnin[i,3],res.burnin[i,4],RadConst = r.const$val,det.eff=as.numeric(input$recefficiency))
          points(green.line,lwd=3,type="l",col=rgb(0,1,0,0.2))
          
        }
    })
    


    updateTabsetPanel(session, "resultsTab",
                      selected = "post")

    })
    

    
    observeEvent(input$redrawButton,{
      res.burnin=mcmc.results$data[as.numeric(input$burnin):as.numeric(input$simnum),]
      # res.burnin=res[as.numeric(input$burnin):as.numeric(input$simnum),]
      # res_burnin=res[-c(1:as.numeric(input$burnin)),]
      output$pospost <- renderPlot({
        
        
        minx=min(res.burnin[,1])
        maxx=max(res.burnin[,1])
        miny=min(res.burnin[,2])
        maxy=max(res.burnin[,2])
        cell_size=5
        
        r <- raster(xmn=minx, ymn=miny, xmx=maxx, ymx=maxy, res=cell_size)
        
        
        # lambda_vec_new=data.frame(lambda_vec[1:(sim-burnin),1],lambda_vec[1:(sim-burnin),2])
        lambda_vec_new=data.frame(res.burnin[,1],res.burnin[,2])
        
        sp.new=SpatialPoints(lambda_vec_new)
        
        tab <- table(cellFromXY(r, sp.new))
        r[as.numeric(names(tab))] <- tab
        
        y=r
        
        
        Stat.Sum=cellStats(r,sum) # Counting the number of all points in the r raster layer
        y.scale = y / Stat.Sum*100 
        
        # Classic palette BuPu, with 4 colors
        coul = brewer.pal(9, "YlGnBu")
        # I can add more tones to this palette :
        coul = colorRampPalette(coul)(40)
        
        coordinates.posterior.max=xyFromCell(y.scale,cell=which.max(y.scale))
        
        plot(y.scale,main="Posterior distribution for source position",xlab="x coordinate (m)",ylab="y coordinate (m)",col=coul)
        
        points(mcmc.prepared.data$data[,1],mcmc.prepared.data$data[,2],type="l",lwd=3) 
        
        
        # plot(   res.burnin[,1],res.burnin[,2],col=rgb(1,0,0,0.1)   )
        # points(mcmc.prepared.data$data[,1],mcmc.prepared.data$data[,2],type="l")
        # points(   res[,1],res[,2],col=rgb(1,0,0,1)   )
      })
      
      
      output$actpost <- renderPlot({
        plot( density(  res.burnin[,3] )   ,main="Posterior distribution of source activity",xlab="Activity (MBq)")
        abline(v=input$sact,lwd=3,lty=3,col=2)
      })
      
      
      output$datafits <- renderPlot({
        plot(mcmc.prepared.data$data[,3],main="Fit of the peak in measurement time-series",xlab="Measurement index",ylab="CPS")
        for(i in seq(1,length(res.burnin[,1]),by=1000))
        {
          green.line=mean_func_basic(mcmc.prepared.data$data[,1],mcmc.prepared.data$data[,2],res.burnin[i,1],res.burnin[i,2],res.burnin[i,3],res.burnin[i,4],RadConst = r.const$val,det.eff=as.numeric(input$recefficiency))
          points(green.line,lwd=3,type="l",col=rgb(0,1,0,0.2))
        }
      })
      
      
      
      updateTabsetPanel(session, "resultsTab",
                        selected = "post")
      
      
    })


    # observeEvent(input$efficiency,{cat("lol")})



    # observeEvent(input$efficiency,{r.const$val=fSetRadConst(efficiency = as.numeric(input$efficiency) )
    #                                                         cat("\nEfficiency updated\n")
    #
    #                                                         })

    # observeEvent(input$effButton,{r.const$val=fSetRadConst(efficiency = as.numeric(input$efficiency))})


    observeEvent(input$generateButton,{
      
      
      # updateRadioButtons(session, "radioset",selected = "upl")
      updateRadioButtons(session, "radioset",selected = "sim")
      
      # fGenerateDataNew=function(s.x=0,s.y=50,activity=100,background=10,start.x=-100,speed=10.4,acq.t=1,data.span=100,rconst=RadConst)
        
      
      
      # gen.data=fGenerateData(s.x = as.numeric(input$sx),s.y = as.numeric(input$sy),background=as.numeric(input$back),data.span=as.numeric(input$dataspan),activity = as.numeric(input$sact),rconst = r.const$val)
      gen.data=fGenerateDataNew(d.efficiency=as.numeric(input$efficiency),s.x = as.numeric(input$sx),s.y = as.numeric(input$sy),background=as.numeric(input$back),data.span=as.numeric(input$dataspan),activity = as.numeric(input$sact),start.x=as.numeric(input$xstart),speed=as.numeric(input$speed),acq.t=as.numeric(input$acqt),rconst = r.const$val)
      
      
      
      
      # textInput("efficiency", "Efficiency of the detector (m^2)", "0.02"),
      
      # textInput("sx", "x position of the source (m)", "0"),
      # 
      # textInput("sy", "y position of the source (m)", "60"),
      # 
      # textInput("sact", "Activity of the source (MBq)", "100"),
      # 
      # textInput("back", "Background count-rate (cps)", "10"),
      # 
      # textInput("xstart", "Number of data points", "-100"),
      # 
      # textInput("speed", "Detector speed (m/s)", "13.9"),
      # 
      # textInput("acqt", "Acquisition time (s)", "1"),
      # 
      # textInput("dataspan", "Number of data points", "200"),


    output$generateddata <- renderPlot({
      plot( gen.data[,3] ,type="l"  )
      generated.data$data=gen.data
    })

    updateTabsetPanel(session, "resultsTab",
                      selected = "gen")

            })



    observeEvent(input$proccsvButton,{
      updateTabsetPanel(session, "resultsTab",
                        selected = "input")
      
      
      updateRadioButtons(session, "radioset",selected = "upl")
      # updateRadioButtons(session, "radioset",selected = "sim")
      
     
      
      if(max(csv.data$data[,1])<14)
      {
        data.coordinates=csv.data$data[,c(1,2)]
        
      }else{
        data.coordinates=csv.data$data[,c(2,1)]
      }
      # data.coordinates=csv.data$data[,1:2]
      
      conv.data.coords=fWgsToMercator(data.coordinates[,1],data.coordinates[,2])
      
      
      # if(co)
      
      conv.data.coords[,1]=conv.data.coords[,1]-max(conv.data.coords[,1])
      conv.data.coords[,2]=conv.data.coords[,2]-max(conv.data.coords[,2])
      
      uploaded.data$data=data.frame(conv.data.coords[,1],conv.data.coords[,2],csv.data$data[,3])


      output$inputdata <- renderPlot({
        plot( uploaded.data$data[,3], main="Measured values",xlab="Measurement index",ylab="CPS" )
      })
      
      output$inputdata2 <- renderPlot({
        plot( uploaded.data$data[,1], uploaded.data$data[,2],type="l" ,main="Measurement track")
      })
      

      updateSliderInput(session, "datarange", value=c(1,length(uploaded.data$data[,3])),
                        min = 1, max=length(uploaded.data$data[,3]),step=1)

    })



    observeEvent(input$procnblButton,{
      
      
      # radioButtons("radioset", "Use data:",
      #              c("Simulated" = "sim",
      #                "Uploaded" = "upl")),
      
      updateRadioButtons(session, "radioset",selected = "upl")
      # updateRadioButtons(session, "radioset",selected = "sim")
      
      updateTabsetPanel(session, "resultsTab",
                        selected = "input")

      
      
      
      
      
      if(input$detset=="nai1")
      {
        # if det 1
        req(input$nbl1)
        cat("proc nbl1")

        # df <- read.csv(input$nbl1$datapath)
        cat(input$nbl1$datapath)
        
        
        data.coordinates=fReadNBL_test(file.path = input$nbl1$datapath,NBL.type = 1)[,1:2]
        conv.data.coords=fWgsToMercator(data.coordinates[,1],data.coordinates[,2])

        conv.data.coords[,1]=conv.data.coords[,1]-max(conv.data.coords[,1])
        conv.data.coords[,2]=conv.data.coords[,2]-max(conv.data.coords[,2])
        data.nai1=fReadNBL_test(file.path = input$nbl1$datapath ,NBL.type = 1)[,-c(1,2)]



        data.nai1.ROI=fPreapareRois(data.nai1,background_correction = F)
        # data.nai1=rowSums(data.nai1)
        data.comp=data.frame(as.numeric(conv.data.coords[,1]),as.numeric(conv.data.coords[,2]),as.numeric(data.nai1.ROI))[-c(1,2,3),]
        # cat(data.comp[,3])
        uploaded.data$data=data.comp






        # updateSliderInput(session, "datarange", value=c(1,10),min = 1, max=20,step=1);





      }else{

        if(input$detset=="nai2")
        {
          # if det 2
          req(input$nbl1)
          req(input$nbl2)
          cat("proc nbl2")
          
          data.coordinates=fReadNBL_test(file.path = input$nbl1$datapath,NBL.type = 1)[,1:2]
          conv.data.coords=fWgsToMercator(data.coordinates[,1],data.coordinates[,2])
          
          conv.data.coords[,1]=conv.data.coords[,1]-max(conv.data.coords[,1])
          conv.data.coords[,2]=conv.data.coords[,2]-max(conv.data.coords[,2])
          
          # data.nai1=fReadNBL_setup_test(data.path = nbl.data.path ,name_iterator = setup_number,NBL.type = 1)
          # data.nai2=fReadNBL_setup_test(data.path = nbl.data.path ,name_iterator = setup_number,NBL.type = 2)
          data.nai2=fReadNBL_test(file.path = input$nbl2$datapath,NBL.type = 2)
          
          
          data.nai2.ROI=fPreapareRois(data.nai2,background_correction = F)
          # data.nai1=rowSums(data.nai1)
          data.comp=data.frame(as.numeric(conv.data.coords[,1]),as.numeric(conv.data.coords[,2]),as.numeric(data.nai2.ROI))[-c(1,2,3),]
          # cat(data.comp[,3])
          uploaded.data$data=data.comp
          
          
          
          


        }else{
          # if hpge
          req(input$nbl1)
          req(input$nbl3)
          cat("proc nbl3")
          
          data.coordinates=fReadNBL_test(file.path = input$nbl1$datapath,NBL.type = 1)[,1:2]
          conv.data.coords=fWgsToMercator(data.coordinates[,1],data.coordinates[,2])
          
          conv.data.coords[,1]=conv.data.coords[,1]-max(conv.data.coords[,1])
          conv.data.coords[,2]=conv.data.coords[,2]-max(conv.data.coords[,2])
          
          # data.nai1=fReadNBL_setup_test(data.path = nbl.data.path ,name_iterator = setup_number,NBL.type = 1)
          # data.hpge=fReadNBL_setup_test(data.path = nbl.data.path ,name_iterator = setup_number,NBL.type = 3)
          data.hpge=fReadNBL_test(file.path = input$nbl3$datapath,NBL.type = 3)
          
          
          
          
          data.hpge.ROI=fPreapareRois(data.hpge,background_correction = F)
          # data.nai1=rowSums(data.nai1)
          data.comp=data.frame(as.numeric(conv.data.coords[,1]),as.numeric(conv.data.coords[,2]),as.numeric(data.hpge.ROI))[-c(1,2,3),]
          # cat(data.comp[,3])
          uploaded.data$data=data.comp


        }





      }


      output$inputdata <- renderPlot({
        # par(mfrow=c(1,1))
        # plot( uploaded.data$data[,1]  )
        # plot( uploaded.data$data[,2]  )
        plot( uploaded.data$data[,3]  )
        abline(v=c(input$datarange[1],input$datarange[2]),col=2,lwd=2)
      })
      
      
      
      
      updateSliderInput(session, "datarange", value=c(1,length(uploaded.data$data[,3])),
                        min = 1, max=length(uploaded.data$data[,3]),step=1)


      output$inputdata2 <- renderPlot({
        plot( uploaded.data$data[,1], uploaded.data$data[,2],type="l" ,main="Measurement track",xlab="x coordinate (m)",ylab="y coordinate (m)")
      })




    })


    observeEvent(input$datarange,{
      # req(input$nbl1)
      
      if(length(   as.vector(uploaded.data$data)  )>1)
      {
        output$inputdata <- renderPlot({
          # plot( uploaded.data$data[,3]  )
          plot( uploaded.data$data[,3], main="Measured values",xlab="Measurement index",ylab="CPS" )
          abline(v=c(input$datarange[1],input$datarange[2]),col=2,lwd=2)
          
          
        })
        
        output$inputdata2 <- renderPlot({
          # plot( uploaded.data$data[,3]  )
          plot( uploaded.data$data[,1], uploaded.data$data[,2],type="l" ,main="Measurement track",xlab="x coordinate (m)",ylab="y coordinate (m)")
          points( uploaded.data$data[input$datarange[1]:input$datarange[2],1], uploaded.data$data[input$datarange[1]:input$datarange[2],2],type="l" ,col=2,lwd=3,main="Measurement track",xlab="x coordinate (m)",ylab="y coordinate (m)")
          
          # abline(v=c(input$datarange[1],input$datarange[2]),col=2,lwd=2)
          
          
        })
        
        output$inputdata3 <- renderPlot({
          # plot( uploaded.data$data[,3]  )
          plot(  uploaded.data$data[input$datarange[1]:input$datarange[2],3],type="l" ,main="Selected measurements track",xlab="Measurement index",ylab="CPS")
          # plot(,type="l" ,col=2,lwd=3,main="Measurement track",xlab="x coordinate (m)",ylab="y coordinate (m)")
          
          # abline(v=c(input$datarange[1],input$datarange[2]),col=2,lwd=2)
          
          
        })
        
        
        
        
      }
    })
    
}

# Run the application 
shinyApp(ui = ui, server = server)

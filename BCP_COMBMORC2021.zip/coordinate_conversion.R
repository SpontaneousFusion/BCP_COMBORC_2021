##
#   Source data preparation
#
#   This function is invoked in the main program and returns a dataframe with the
#   source name, true source activity, true source distance and true source coordiantes

#   Created:  2018-12-11
#
#   Updated: 2018-12-11
#
##

 # library(rgdal)
 library(sp)
 # require(geoR)


fWgsToMercator=function(long_coord,lat_coord)
{

  Coordinates.for.conversion=data.frame(long_coord,lat_coord)
  sp1 = SpatialPoints(Coordinates.for.conversion,proj4string=CRS("+proj=longlat +datum=WGS84"))
  transformed = spTransform(sp1,CRS("+proj=utm +zone=33u +datum=WGS84"))
  Coordinates.after.conversion=coordinates(transformed)
  return(Coordinates.after.conversion)
}

